#include "Solicitud.h"
#include "mensaje.h"

Solicitud::Solicitud(struct timeval timeout) {
	timeoutSocket = timeout;
	socketlocal = new SocketDatagrama(0,timeout);
}

char * Solicitud::doOperation(char* IP, int puerto, int operationId, char* arguments) {
	struct mensaje mensaje;
	char* resultado;
	int respuesta;

	for(int i=0;i<7;i++){	
		mensaje.messageType = 0;
		mensaje.requestId = id;
		id++;

		memcpy(mensaje.IP, IP, 16);
		mensaje.puerto = puerto;
		mensaje.operationId = operationId;	
		
		memcpy(mensaje.arguments, arguments, TAM_MAX_DATA);

		PaqueteDatagrama paq((char*) &mensaje, sizeof(mensaje), IP, puerto);
		socketlocal->envia(paq);
		PaqueteDatagrama paq1(sizeof(mensaje));
		respuesta = socketlocal->recibeTimeout(paq1,timeoutSocket.tv_sec,timeoutSocket.tv_usec);
		
		if(respuesta>=0){
			resultado = paq1.obtieneDatos();
			break;
		}
	}	

	if(respuesta>=0) {}
		// cout << "\tResultado: " << resultado << endl;
	else {}
		// cout << "\tNo se pudo conectar al servidor :(" << endl;

	return resultado;
}
