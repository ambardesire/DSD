#define __RESPUESTA__

#include "SocketDatagrama.h"
#include "mensaje.h"

class Respuesta {
    private:
        SocketDatagrama *socketlocal;
        struct mensaje *palabras;
        struct timeval timeoutSocket;
    public:
        Respuesta(int pl);
        struct mensaje *getRequest(void);
        void sendReply(char *respuesta, char *ipCliente, int puertoCliente);
};