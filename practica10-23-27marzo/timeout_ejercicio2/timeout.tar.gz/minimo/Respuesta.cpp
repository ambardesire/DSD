#include "Respuesta.h"

#include <iostream>
using namespace std;

Respuesta::Respuesta(int pl) {
	socketlocal = new SocketDatagrama(pl);
}

struct mensaje* Respuesta::getRequest() {
	PaqueteDatagrama paquete(sizeof(mensaje));
	socketlocal->recibe(paquete);
	palabras = (struct mensaje*) paquete.obtieneDatos();
	cout << "Conexion iniciada" << endl;
	cout << "\tId es: " <<  palabras->operationId << endl;
	cout << "\tArgumentos: " <<  palabras->arguments << endl;
	cout << "\tIp: " << palabras->IP << endl;
	cout << "\tTipo: " << palabras->messageType << endl;
	palabras->puerto = paquete.obtienePuerto();
	memcpy(palabras->IP,paquete.obtieneDireccion(),16);
	cout << "\tPuerto: " << palabras->puerto << endl;

	return palabras;
}

void Respuesta::sendReply(char * respuesta, char * ipCliente, int puertoCliente) {
	struct mensaje *mensaje_respuesta;
	mensaje_respuesta = (struct mensaje *) respuesta;

	PaqueteDatagrama paquete((char*) mensaje_respuesta, 100, ipCliente, puertoCliente);
	cout << "\tRespuesta: " << paquete.obtieneDatos();
	socketlocal->envia(paquete);
	cout<<"\n";
}
