#include "Solicitud.h"

#include <iostream>
#include <stdlib.h>
#include <string.h>

using namespace std;

int main(int argc, char*argv[]) {
	struct timeval timeout;
    timeout.tv_sec = 2;
    timeout.tv_usec = 500000;
	
	char arreglo[4000] ="";

	int op = 1;

		strcat(arreglo,argv[3]);
		strcat(arreglo," ");
		strcat(arreglo,argv[4]);

	Solicitud cliente = Solicitud(timeout);	

	for (int i=0 ; i<atoi(argv[5]) ; i++) {

		printf("Operacion iniciada con %s y %s\n\n", argv[3], argv[4]);
		
		cliente.doOperation(argv[1], atoi(argv[2]), op, arreglo);
	}

	return 0;
}