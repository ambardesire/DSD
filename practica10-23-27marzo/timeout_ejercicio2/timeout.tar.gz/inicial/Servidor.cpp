#include <cstdlib>
#include <iostream> 
#include <string> 
#include "Respuesta.h"

using namespace std;

char * suma (char * data) {
	string respuesta (" "), elem;
	size_t size_data = strlen(data);
	int num, res = 0;

	for (size_t i = 0;i < size_data+1;i++) {
		unsigned char c = data[i];
		switch (c)
		{
			default:
				elem += c;
				break;
			case '\0':
			case '\n':
			case ' ':
				if(!elem.empty ()) {
					num = stoi(elem);
			        res = res + num;
					elem.clear();
				}
				break;
		}
	}
	respuesta = std::to_string(res);
    char *resp = new char[respuesta.size()];
	memcpy (resp,respuesta.c_str(),respuesta.size());

	return resp;
}

int main(int argc, char *argv[]) {
	cout << "Servidor iniciado..."<<endl;

	Respuesta respuesta(atoi(argv[1]));

	while(1) {
		struct mensaje mensaje_recibido;
		struct mensaje mensaje_aux;
			
        cout << "\nEsperando conexion : " << endl;
        memcpy(&mensaje_recibido, respuesta.getRequest(), sizeof(struct mensaje));
    
        if (mensaje_recibido.operationId==1) {
				// bzero((char *)&mensaje_aux, sizeof(mensaje_aux));
				// bzero((char *)&mensaje_recibido, sizeof(mensaje_recibido));
                memcpy(mensaje_aux.arguments, suma(mensaje_recibido.arguments), strlen(mensaje_recibido.arguments));
                mensaje_aux.messageType = 1;
                memcpy(mensaje_aux.IP, mensaje_recibido.IP, 16);
                mensaje_aux.puerto = mensaje_recibido.puerto;
                mensaje_aux.requestId = mensaje_recibido.requestId;
                respuesta.sendReply((char*) mensaje_aux.arguments,mensaje_aux.IP, mensaje_recibido.puerto);
		}
	}

	return 0;
}