### Servdidor
make Servidor <br>
./Servidor <puerto_local> <br>
Ej. ./Servidor <br>

### Cliente
make Cliente <br>
./Cliente <ip_remota> <puerto_remoto> <no_depositos> <br>
Ej. ./Cliente 127.0.0.1 7200 5 <br>
